from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.v1.router import api_router
from app.core.config import settings
from app.db.init_db import init_db
app=FastAPI(title=settings.PROJECT_NAME,version='1.0.0')
app.add_middleware(CORSMiddleware,allow_origins=settings.ALLOWED_ORIGINS,allow_credentials=True,allow_methods=['*'],allow_headers=['*'])
@app.on_event('startup')
def startup(): init_db()
app.include_router(api_router,prefix=settings.API_V1_STR)
@app.get('/')
def root(): return {'name':settings.PROJECT_NAME,'status':'running','version':'1.0.0'}
@app.get('/health')
def health(): return {'status':'healthy'}
