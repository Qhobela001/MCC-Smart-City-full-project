from sqlalchemy import select
from app.modules.users.models import User
def list_all(db): return list(db.scalars(select(User).order_by(User.full_name)).unique().all())
def get(db,id): return db.get(User,id)
def create(db,obj): db.add(obj); db.commit(); db.refresh(obj); return obj
