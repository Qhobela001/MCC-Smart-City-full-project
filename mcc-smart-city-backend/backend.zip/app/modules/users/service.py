from fastapi import HTTPException
from sqlalchemy import select
from app.core.security import get_password_hash,verify_password
from app.modules.users.models import User
def ensure_unique(db,email,employee_number=None,phone=None,exclude=None):
 for field,value in [('email',email.lower() if email else None),('employee_number',employee_number),('phone_number',phone)]:
  if value and (u:=db.scalar(select(User).where(getattr(User,field)==value))) and u.id!=exclude: raise HTTPException(409,f'{field.replace("_"," ").title()} already exists')
def change_password(db,user,current,new):
 if not verify_password(current,user.hashed_password): raise HTTPException(400,'Current password is incorrect')
 if len(new)<8: raise HTTPException(400,'New password must contain at least 8 characters')
 user.hashed_password=get_password_hash(new); user.must_change_password=False; db.commit(); db.refresh(user); return user
