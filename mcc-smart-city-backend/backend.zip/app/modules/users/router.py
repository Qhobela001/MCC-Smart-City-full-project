from fastapi import APIRouter,Depends,HTTPException
from sqlalchemy.orm import Session
from app.core.deps import get_current_user,get_db,require_permission,require_superadmin
from app.core.security import get_password_hash
from app.modules.users import repository,service
from app.modules.users.models import User
from app.modules.users.schemas import *
router=APIRouter(prefix='/users',tags=['Users'])
@router.get('',response_model=list[UserRead])
def all(db:Session=Depends(get_db),_=Depends(require_permission('users.view'))): return repository.list_all(db)
@router.post('',response_model=UserRead,status_code=201)
def create(p:UserCreate,db:Session=Depends(get_db),actor=Depends(require_permission('users.create'))):
 if p.is_superuser and not actor.is_superuser: raise HTTPException(403,'Only a SuperAdmin can create another SuperAdmin')
 service.ensure_unique(db,p.email,p.employee_number,p.phone_number); data=p.model_dump(exclude={'temporary_password'}); data['email']=data['email'].lower(); data['hashed_password']=get_password_hash(p.temporary_password)
 return repository.create(db,User(**data,must_change_password=True,is_active=True))
@router.patch('/{id}',response_model=UserRead)
def update(id:int,p:UserUpdate,db:Session=Depends(get_db),actor=Depends(require_permission('users.update'))):
 o=repository.get(db,id)
 if not o: raise HTTPException(404,'User not found')
 data=p.model_dump(exclude_unset=True); service.ensure_unique(db,data.get('email',o.email),data.get('employee_number',o.employee_number),data.get('phone_number',o.phone_number),id)
 for k,v in data.items(): setattr(o,k,v.lower() if k=='email' and v else v)
 db.commit();db.refresh(o);return o
@router.post('/change-password',response_model=UserRead)
def change_password(p:PasswordChange,db:Session=Depends(get_db),user=Depends(get_current_user)): return service.change_password(db,user,p.current_password,p.new_password)
@router.post('/{id}/reset-password',response_model=UserRead)
def reset_password(id:int,p:PasswordResetByAdmin,db:Session=Depends(get_db),_=Depends(require_permission('users.reset_password'))):
 o=repository.get(db,id)
 if not o: raise HTTPException(404,'User not found')
 o.hashed_password=get_password_hash(p.new_temporary_password);o.must_change_password=True;db.commit();db.refresh(o);return o
