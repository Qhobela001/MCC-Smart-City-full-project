from datetime import datetime
from pydantic import BaseModel, ConfigDict

from app.modules.departments.schemas import DepartmentRead
from app.modules.roles.schemas import RoleRead
from app.modules.users.models import UserStatus
class UserCreate(BaseModel):
 full_name:str; employee_number:str|None=None; email:str; phone_number:str|None=None; department_id:int|None=None; role_id:int|None=None; temporary_password:str; status:UserStatus=UserStatus.active; is_superuser:bool=False
class UserUpdate(BaseModel):
 full_name:str|None=None; employee_number:str|None=None; email:str|None=None; phone_number:str|None=None; department_id:int|None=None; role_id:int|None=None; status:UserStatus|None=None; is_active:bool|None=None
class PasswordChange(BaseModel): current_password:str; new_password:str
class PasswordResetByAdmin(BaseModel): new_temporary_password:str
class UserRead(BaseModel):
 id:int; full_name:str; employee_number:str|None; email:str; phone_number:str|None; department_id:int|None; role_id:int|None; status:UserStatus; is_active:bool; is_superuser:bool; must_change_password:bool
 department:DepartmentRead|None=None; role:RoleRead|None=None; created_at:datetime; updated_at:datetime
 model_config=ConfigDict(from_attributes=True)
