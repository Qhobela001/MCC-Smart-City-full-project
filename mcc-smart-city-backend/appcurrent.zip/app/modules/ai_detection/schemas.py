from pydantic import BaseModel, Field


# ============================================================
# BOUNDING BOX
# ============================================================

class BoundingBox(BaseModel):

    x1: float
    y1: float
    x2: float
    y2: float

    width: float
    height: float


# ============================================================
# SINGLE DETECTION
# ============================================================

class DetectionResult(BaseModel):

    class_id: int

    class_name: str

    confidence: float = Field(
        ge=0.0,
        le=1.0,
    )

    bbox: BoundingBox


# ============================================================
# DETECTION RESPONSE
# ============================================================

class DetectionResponse(BaseModel):

    filename: str

    detections_count: int

    detections: list[
        DetectionResult
    ]


# ============================================================
# MODEL INFORMATION
# ============================================================

class ModelInfoResponse(BaseModel):

    model_name: str

    number_of_classes: int

    classes: dict[int, str]