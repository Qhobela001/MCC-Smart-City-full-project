from fastapi import (
    APIRouter,
    File,
    HTTPException,
    Query,
    UploadFile,
    status,
)

from .schemas import (
    DetectionResponse,
    ModelInfoResponse,
)

from .service import (
    ai_detection_service,
)


router = APIRouter(
    prefix="/ai-detection",
    tags=["AI Detection"],
)


# ============================================================
# MODEL INFORMATION
# ============================================================

@router.get(
    "/model",
    response_model=ModelInfoResponse,
)
def get_model_information():

    return (
        ai_detection_service
        .model_info()
    )


# ============================================================
# IMAGE DETECTION
# ============================================================

@router.post(
    "/detect",
    response_model=DetectionResponse,
    status_code=status.HTTP_200_OK,
)
async def detect_image(
    file: UploadFile = File(...),

    confidence: float = Query(
        default=0.25,
        ge=0.01,
        le=1.0,
        description=(
            "Minimum confidence "
            "threshold for detections."
        ),
    ),
):

    try:

        return await (
            ai_detection_service
            .detect_uploaded_image(
                file=file,
                confidence=confidence,
            )
        )

    except ValueError as exc:

        raise HTTPException(
            status_code=400,
            detail=str(exc),
        ) from exc

    except FileNotFoundError as exc:

        raise HTTPException(
            status_code=500,
            detail=str(exc),
        ) from exc

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=(
                "AI detection failed: "
                f"{exc}"
            ),
        ) from exc