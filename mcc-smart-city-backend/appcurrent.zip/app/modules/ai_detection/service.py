from pathlib import Path
from tempfile import NamedTemporaryFile
import os

from fastapi import UploadFile

from .detector import detector


# ============================================================
# SUPPORTED IMAGE FORMATS
# ============================================================

SUPPORTED_IMAGE_EXTENSIONS = {
    ".jpg",
    ".jpeg",
    ".png",
    ".bmp",
    ".webp",
}


# ============================================================
# AI DETECTION SERVICE
# ============================================================

class AIDetectionService:

    # ========================================================
    # DETECT UPLOADED IMAGE
    # ========================================================

    async def detect_uploaded_image(
        self,
        file: UploadFile,
        confidence: float = 0.25,
    ) -> dict:

        filename = (
            file.filename
            or "uploaded_image.jpg"
        )

        extension = Path(
            filename
        ).suffix.lower()

        if (
            extension
            not in SUPPORTED_IMAGE_EXTENSIONS
        ):
            raise ValueError(
                "Unsupported image format. "
                "Supported formats: "
                ".jpg, .jpeg, .png, "
                ".bmp, .webp"
            )

        temp_path: str | None = None

        try:

            contents = await file.read()

            if not contents:
                raise ValueError(
                    "Uploaded image is empty."
                )

            with NamedTemporaryFile(
                delete=False,
                suffix=extension,
            ) as temp_file:

                temp_file.write(
                    contents
                )

                temp_path = (
                    temp_file.name
                )

            detections = detector.detect(
                source=temp_path,
                confidence=confidence,
            )

            return {
                "filename": filename,
                "detections_count": len(
                    detections
                ),
                "detections": detections,
            }

        finally:

            if (
                temp_path
                and os.path.exists(
                    temp_path
                )
            ):
                os.remove(
                    temp_path
                )


    # ========================================================
    # DETECT LOCAL IMAGE
    # ========================================================

    def detect_local_image(
        self,
        image_path: str | Path,
        confidence: float = 0.25,
    ) -> dict:

        image_path = Path(
            image_path
        )

        if not image_path.exists():
            raise FileNotFoundError(
                f"Image not found: "
                f"{image_path}"
            )

        detections = detector.detect(
            source=str(image_path),
            confidence=confidence,
        )

        return {
            "filename": (
                image_path.name
            ),
            "detections_count": len(
                detections
            ),
            "detections": detections,
        }


    # ========================================================
    # MODEL INFORMATION
    # ========================================================

    def model_info(
        self,
    ) -> dict:

        info = (
            detector.get_model_info()
        )

        return {
            "model_name": (
                info["model_name"]
            ),
            "number_of_classes": (
                info[
                    "number_of_classes"
                ]
            ),
            "classes": (
                info["classes"]
            ),
        }


ai_detection_service = (
    AIDetectionService()
)