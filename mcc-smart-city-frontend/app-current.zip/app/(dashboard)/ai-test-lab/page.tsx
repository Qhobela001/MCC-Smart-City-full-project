"use client"

import { FormEvent, useMemo, useRef, useState } from "react"
import {
  Activity,
  BrainCircuit,
  CheckCircle2,
  FileVideo,
  ImageIcon,
  Link2,
  Loader2,
  ScanLine,
  ShieldAlert,
  Sparkles,
  Upload,
  ChevronLeft,
  ChevronRight,
  Gauge,
} from "lucide-react"

import { apiFetch } from "@/lib/api"


type BBox = {
  x1: number
  y1: number
  x2: number
  y2: number
  width: number
  height: number
}

type Detection = {
  class_id: number
  class_name: string
  confidence: number
  bbox: BBox
  source: string
  track_id?: string | null
  parent_detection_index?: number | null
  tracking_state?: "detected" | "predicted" | string
  is_predicted?: boolean
  seconds_since_detection?: number
  waste_state?: string | null
  associated_actor_track_id?: string | null
  associated_actor_kind?: string | null
  associated_waste_track_ids?: string[]
  dumping_role?: string | null
  original_class_name?: string | null
}

type Association = {
  association_type: string
  left_index: number
  left_class: string
  left_track_id?: string | null
  right_index: number
  right_class: string
  right_track_id?: string | null
  relation: string
  confidence: number
  metadata: Record<string, unknown>
}

type RuleAssessment = {
  rule: string
  title: string
  status: string
  confidence: number
  reasons: string[]
  evidence_classes: string[]
  incident_type?: string | null
  related_track_ids: string[]
  details: Record<string, unknown>
}

type Occurrence = {
  occurrence_id: string
  occurrence_type: string
  title: string
  status: string
  confidence: number
  reasons: string[]
  evidence_classes: string[]
  track_ids: string[]
  incident_type?: string | null
  vehicle_track_id?: string | null
  person_track_ids: string[]
  waste_track_ids: string[]
  plate_track_id?: string | null
  plate_status?: string | null
  follow_up?: string | null
  details: Record<string, unknown>
}

type StreetCleanliness = {
  score: number
  state: string
  loose_waste_count: number
  contained_waste_count: number
  waste_around_skip_count: number
  waste_above_skip_count: number
  total_waste_count: number
  provisional: boolean
  reasons: string[]
  before_score?: number | null
  after_score?: number | null
  change?: number | null
  sampled_assessments?: number | null
}

type CleanerPerformance = {
  status: string
  title: string
  confidence: number
  before_score: number
  after_score: number
  change: number
  reasons: string[]
  related_track_ids: string[]
}

type ImageDetectionResponse = {
  filename: string
  image_width: number
  image_height: number
  detections_count: number
  detections: Detection[]
  associations: Association[]
  rules: RuleAssessment[]
  occurrences: Occurrence[]
  street_cleanliness: StreetCleanliness
}

type VideoClassSummary = {
  class_name: string
  max_confidence: number
  detections: number
}

type VideoTrack = {
  track_id: string
  class_name: string
  first_sampled_frame: number
  last_sampled_frame: number
  hits: number
  predicted_frames?: number
  max_confidence: number
  first_seen_seconds?: number
  last_seen_seconds?: number
}

type AssociationSummary = {
  association_type: string
  hits: number
}

type VideoSampledFrame = {
  sampled_frame: number
  frame_index: number
  time_seconds: number
  image_width: number
  image_height: number
  detections: Detection[]
}

type VideoDetectionResponse = {
  filename: string
  duration_seconds: number
  fps: number
  video_width: number
  video_height: number
  total_frames: number
  sampled_frames: number
  frame_stride: number
  requested_frame_stride?: number | null
  effective_frame_stride?: number | null
  analysis_end_seconds?: number | null
  analysis_coverage_percent?: number | null
  sampled_detections: VideoSampledFrame[]
  predicted_boxes_count?: number
  class_summary: VideoClassSummary[]
  tracks: VideoTrack[]
  association_summary: AssociationSummary[]
  rules: RuleAssessment[]
  occurrences: Occurrence[]
  street_cleanliness?: StreetCleanliness | null
  cleaner_performance?: CleanerPerformance | null
}

function confidencePercent(value: number) {
  return `${(value * 100).toFixed(1)}%`
}

function label(value: string) {
  return value.replaceAll("_", " ")
}

function statusClass(status: string) {
  if (["candidate", "poor", "review"].includes(status)) {
    return "border-amber-500/30 bg-amber-500/10 text-amber-300"
  }
  if (["effective", "clean", "detected"].includes(status)) {
    return "border-emerald-500/30 bg-emerald-500/10 text-emerald-300"
  }
  return "border-blue-500/30 bg-blue-500/10 text-blue-300"
}

function RuleCard({ rule }: { rule: RuleAssessment }) {
  const candidate = rule.status === "candidate"

  return (
    <div className="rounded-lg border border-border bg-muted/25 p-4">
      <div className="flex items-start gap-3">
        <div className={`mt-0.5 rounded-full p-1.5 ${candidate ? "bg-amber-500/15 text-amber-400" : "bg-blue-500/15 text-blue-400"}`}>
          {candidate ? <ShieldAlert className="size-4" /> : <CheckCircle2 className="size-4" />}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <p className="font-medium">{rule.title}</p>
            <span className="rounded-full border border-border px-2 py-0.5 text-[11px] uppercase tracking-wide text-muted-foreground">
              {rule.status}
            </span>
            <span className="text-xs text-muted-foreground">{confidencePercent(rule.confidence)}</span>
          </div>
          {rule.incident_type && (
            <p className="mt-1 text-xs text-primary">Incident mapping: {label(rule.incident_type)}</p>
          )}
          <ul className="mt-2 space-y-1 text-sm text-muted-foreground">
            {rule.reasons.map((reason) => <li key={reason}>• {reason}</li>)}
          </ul>
          {rule.related_track_ids.length > 0 && (
            <p className="mt-2 text-xs text-muted-foreground">Tracks: {rule.related_track_ids.join(", ")}</p>
          )}
          <p className="mt-2 text-xs text-muted-foreground">
            Evidence: {rule.evidence_classes.join(", ") || "none"}
          </p>
        </div>
      </div>
    </div>
  )
}

function OccurrenceCard({ occurrence }: { occurrence: Occurrence }) {
  return (
    <div className="rounded-lg border border-border bg-muted/20 p-4">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <p className="font-medium">{occurrence.title}</p>
          <p className="mt-1 font-mono text-[11px] text-muted-foreground">{occurrence.occurrence_id}</p>
        </div>
        <div className="flex items-center gap-2">
          <span className={`rounded-full border px-2 py-0.5 text-[11px] uppercase ${statusClass(occurrence.status)}`}>
            {occurrence.status}
          </span>
          <span className="text-xs text-muted-foreground">{confidencePercent(occurrence.confidence)}</span>
        </div>
      </div>

      <div className="mt-3 grid gap-2 text-xs sm:grid-cols-2">
        {occurrence.vehicle_track_id && <InfoRow name="Vehicle" value={occurrence.vehicle_track_id} />}
        {occurrence.plate_status && occurrence.plate_status !== "not_applicable" && (
          <InfoRow name="Plate status" value={label(occurrence.plate_status)} />
        )}
        {occurrence.plate_track_id && <InfoRow name="Plate track" value={occurrence.plate_track_id} />}
        {occurrence.occurrence_type === "vehicle_emission" && typeof occurrence.details.smoke_window_hits === "number" && (
          <InfoRow name="Smoke hits in window" value={String(occurrence.details.smoke_window_hits)} />
        )}
        {occurrence.occurrence_type === "vehicle_emission" && typeof occurrence.details.smoke_window_seconds === "number" && (
          <InfoRow name="Evidence window" value={`${Number(occurrence.details.smoke_window_seconds).toFixed(1)}s`} />
        )}
        {occurrence.occurrence_type === "vehicle_emission" && typeof occurrence.details.evidence_strength === "string" && (
          <InfoRow name="Evidence strength" value={label(String(occurrence.details.evidence_strength))} />
        )}
        {occurrence.person_track_ids.length > 0 && <InfoRow name="Person track(s)" value={occurrence.person_track_ids.join(", ")} />}
        {occurrence.waste_track_ids.length > 0 && <InfoRow name="Waste track(s)" value={occurrence.waste_track_ids.join(", ")} />}
      </div>

      <ul className="mt-3 space-y-1 text-sm text-muted-foreground">
        {occurrence.reasons.map((reason) => <li key={reason}>• {reason}</li>)}
      </ul>

      {occurrence.follow_up && (
        <div className="mt-3 rounded-md border border-primary/20 bg-primary/5 px-3 py-2 text-xs text-muted-foreground">
          <span className="font-medium text-foreground">Follow-up: </span>{occurrence.follow_up}
        </div>
      )}
    </div>
  )
}

function CleanlinessCard({ value }: { value: StreetCleanliness }) {
  return (
    <section className="rounded-xl border border-border bg-card p-5 shadow-sm">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <Sparkles className="size-4 text-primary" />
            <h2 className="font-semibold">Street cleanliness</h2>
          </div>
          <p className="mt-1 text-xs text-muted-foreground">Provisional visible-zone condition, not a final MCC field rating.</p>
        </div>
        <span className={`rounded-full border px-2.5 py-1 text-xs font-medium uppercase ${statusClass(value.state)}`}>
          {value.state}
        </span>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3">
        <Metric label="Score" value={`${value.score.toFixed(1)}/100`} />
        <Metric label="Loose waste" value={String(value.loose_waste_count)} />
        <Metric label="Inside skip" value={String(value.contained_waste_count)} />
        <Metric label="Around / above skip" value={String(value.waste_around_skip_count + value.waste_above_skip_count)} />
      </div>

      {value.before_score != null && value.after_score != null && (
        <div className="mt-3 rounded-lg bg-muted/30 px-3 py-2 text-xs text-muted-foreground">
          Video change: {value.before_score.toFixed(1)} → {value.after_score.toFixed(1)} ({(value.change ?? 0) >= 0 ? "+" : ""}{(value.change ?? 0).toFixed(1)})
        </div>
      )}

      <ul className="mt-3 space-y-1 text-xs text-muted-foreground">
        {value.reasons.map((reason) => <li key={reason}>• {reason}</li>)}
      </ul>
    </section>
  )
}

function CleanerPerformanceCard({ value }: { value: CleanerPerformance }) {
  return (
    <section className="rounded-xl border border-border bg-card p-5 shadow-sm">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Activity className="size-4 text-primary" />
          <h2 className="font-semibold">Cleaner performance</h2>
        </div>
        <span className={`rounded-full border px-2.5 py-1 text-xs font-medium uppercase ${statusClass(value.status)}`}>
          {value.status}
        </span>
      </div>
      <p className="mt-3 text-sm font-medium">{value.title}</p>
      <div className="mt-3 grid grid-cols-3 gap-2">
        <Metric label="Before" value={value.before_score.toFixed(1)} />
        <Metric label="After" value={value.after_score.toFixed(1)} />
        <Metric label="Change" value={`${value.change >= 0 ? "+" : ""}${value.change.toFixed(1)}`} />
      </div>
      <ul className="mt-3 space-y-1 text-xs text-muted-foreground">
        {value.reasons.map((reason) => <li key={reason}>• {reason}</li>)}
      </ul>
    </section>
  )
}

export default function AITestLabPage() {
  const [mode, setMode] = useState<"image" | "video">("image")
  const [file, setFile] = useState<File | null>(null)
  const [preview, setPreview] = useState<string | null>(null)
  const [confidence, setConfidence] = useState(0.25)
  const [frameStride, setFrameStride] = useState(2)
  const [enhanceVehicleDetails, setEnhanceVehicleDetails] = useState(true)
  const [carRecoveryConfidence, setCarRecoveryConfidence] = useState(0.15)
  const [smokeDetailConfidence, setSmokeDetailConfidence] = useState(0.12)
  const [plateDetailConfidence, setPlateDetailConfidence] = useState(0.18)
  const [smokeWindowSeconds, setSmokeWindowSeconds] = useState(3.0)
  const [smokeCandidateHits, setSmokeCandidateHits] = useState(2)
  const [smokeStrongHits, setSmokeStrongHits] = useState(3)
  const [currentVideoTime, setCurrentVideoTime] = useState(0)
  const [playbackRate, setPlaybackRate] = useState(0.5)
  const videoRef = useRef<HTMLVideoElement | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [imageResult, setImageResult] = useState<ImageDetectionResponse | null>(null)
  const [videoResult, setVideoResult] = useState<VideoDetectionResponse | null>(null)

  const detectionsByClass = useMemo(() => {
    if (!imageResult) return []
    const map = new Map<string, Detection[]>()
    for (const detection of imageResult.detections) {
      map.set(detection.class_name, [...(map.get(detection.class_name) || []), detection])
    }
    return [...map.entries()]
  }, [imageResult])

  const activeVideoFrame = useMemo(() => {
    const samples = videoResult?.sampled_detections ?? []
    if (samples.length === 0) return null

    let closest = samples[0]
    let closestDistance = Math.abs(samples[0].time_seconds - currentVideoTime)
    for (const sample of samples.slice(1)) {
      const distance = Math.abs(sample.time_seconds - currentVideoTime)
      if (distance < closestDistance) {
        closest = sample
        closestDistance = distance
      }
    }
    return closest
  }, [videoResult, currentVideoTime])

  const activeVideoFrameIndex = useMemo(() => {
    if (!videoResult || !activeVideoFrame) return -1
    return videoResult.sampled_detections.findIndex(
      (sample) => sample.frame_index === activeVideoFrame.frame_index,
    )
  }, [videoResult, activeVideoFrame])

  function seekToSample(offset: number) {
    if (!videoResult || videoResult.sampled_detections.length === 0 || !videoRef.current) return
    const currentIndex = activeVideoFrameIndex >= 0 ? activeVideoFrameIndex : 0
    const nextIndex = Math.min(
      videoResult.sampled_detections.length - 1,
      Math.max(0, currentIndex + offset),
    )
    const sample = videoResult.sampled_detections[nextIndex]
    videoRef.current.pause()
    videoRef.current.currentTime = sample.time_seconds
    setCurrentVideoTime(sample.time_seconds)
  }

  function applyPlaybackRate(rate: number) {
    setPlaybackRate(rate)
    if (videoRef.current) videoRef.current.playbackRate = rate
  }

  function chooseFile(nextFile: File | null) {
    setFile(nextFile)
    setImageResult(null)
    setVideoResult(null)
    setCurrentVideoTime(0)
    setError(null)
    if (preview) URL.revokeObjectURL(preview)
    setPreview(nextFile ? URL.createObjectURL(nextFile) : null)
  }

  async function submit(event: FormEvent) {
    event.preventDefault()
    if (!file) return

    setLoading(true)
    setError(null)
    setImageResult(null)
    setVideoResult(null)

    const body = new FormData()
    body.append("file", file)
    const vehicleParams = `enhance_vehicle_details=${enhanceVehicleDetails}&car_recovery_confidence=${carRecoveryConfidence}&smoke_detail_confidence=${smokeDetailConfidence}&plate_detail_confidence=${plateDetailConfidence}`

    try {
      if (mode === "image") {
        const response = await apiFetch<ImageDetectionResponse>(
          `/ai-detection/detect?confidence=${confidence}&${vehicleParams}`,
          { method: "POST", body },
        )
        setImageResult(response)
      } else {
        const response = await apiFetch<VideoDetectionResponse>(
          `/ai-detection/detect-video?confidence=${confidence}&frame_stride=${frameStride}&smoke_window_seconds=${smokeWindowSeconds}&smoke_candidate_hits=${smokeCandidateHits}&smoke_strong_hits=${smokeStrongHits}&${vehicleParams}`,
          { method: "POST", body },
        )
        setVideoResult(response)
        setCurrentVideoTime(0)
        setPlaybackRate(0.5)
        if (videoRef.current) {
          videoRef.current.pause()
          videoRef.current.currentTime = 0
          videoRef.current.playbackRate = 0.5
        }
      }
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "AI test failed.")
    } finally {
      setLoading(false)
    }
  }

  const rules = imageResult?.rules ?? videoResult?.rules ?? []
  const occurrences = imageResult?.occurrences ?? videoResult?.occurrences ?? []
  const cleanliness = imageResult?.street_cleanliness ?? videoResult?.street_cleanliness ?? null
  const dumpingOccurrences = occurrences.filter((item) => item.occurrence_type === "illegal_dumping")
  const dumpingCandidate = dumpingOccurrences.find((item) => item.status === "candidate")
  const dumpingObservation = dumpingOccurrences.find((item) => item.status === "observation")
  const hasActorEvidence = Boolean(videoResult?.class_summary.some((item) => ["person", "car"].includes(item.class_name) && item.detections > 0))
  const hasPrimaryWasteEvidence = Boolean(videoResult?.class_summary.some((item) => ["trash", "bag"].includes(item.class_name) && item.detections > 0))
  const hasAuxiliaryWasteEvidence = Boolean(videoResult?.sampled_detections.some((frame) => frame.detections.some((item) => item.dumping_role === "unclassified_waste_candidate")))

  return (
    <div className="space-y-5">
      <section className="rounded-xl border border-border bg-card p-5 shadow-sm">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div>
            <div className="flex items-center gap-2">
              <BrainCircuit className="size-5 text-primary" />
              <h1 className="text-xl font-semibold">AI Test Lab</h1>
            </div>
            <p className="mt-2 max-w-3xl text-sm text-muted-foreground">
              Validate raw detections, object associations, tracking, occurrence rules and street-condition intelligence before connecting the production camera pipeline or Jetson Orin Nano.
            </p>
          </div>
          <div className="rounded-lg border border-border bg-muted/35 px-3 py-2 text-xs text-muted-foreground">
            Test-lab results are observations/candidates only. They do not create enforcement incidents.
          </div>
        </div>

        <div className="mt-5 flex gap-2">
          <button
            type="button"
            onClick={() => { setMode("image"); chooseFile(null) }}
            className={`inline-flex items-center gap-2 rounded-md border px-3 py-2 text-sm ${mode === "image" ? "border-primary bg-primary/10 text-primary" : "border-border"}`}
          >
            <ImageIcon className="size-4" /> Image test
          </button>
          <button
            type="button"
            onClick={() => { setMode("video"); chooseFile(null) }}
            className={`inline-flex items-center gap-2 rounded-md border px-3 py-2 text-sm ${mode === "video" ? "border-primary bg-primary/10 text-primary" : "border-border"}`}
          >
            <FileVideo className="size-4" /> Video test
          </button>
        </div>
      </section>

      <section className="grid gap-5 xl:grid-cols-[minmax(0,1.5fr)_minmax(380px,1fr)]">
        <div className="rounded-xl border border-border bg-card p-5 shadow-sm">
          <form onSubmit={submit} className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <label className="space-y-2 text-sm">
                <span className="font-medium">General confidence threshold</span>
                <input
                  type="number" min={0.01} max={1} step={0.01} value={confidence}
                  onChange={(event) => setConfidence(Number(event.target.value))}
                  className="h-10 w-full rounded-md border border-input bg-background px-3"
                />
                <span className="block text-xs text-muted-foreground">Minimum confidence for the normal full-frame detector.</span>
              </label>

              {mode === "video" && (
                <label className="space-y-2 text-sm">
                  <span className="font-medium">Frame stride</span>
                  <input
                    type="number" min={1} max={30} value={frameStride}
                    onChange={(event) => setFrameStride(Number(event.target.value))}
                    className="h-10 w-full rounded-md border border-input bg-background px-3"
                  />
                  <span className="block text-xs text-muted-foreground">Lower values inspect more video frames but take longer.</span>
                </label>
              )}
            </div>

            <div className="rounded-lg border border-border bg-muted/20 p-4">
              <label className="flex items-start gap-3 text-sm">
                <input
                  type="checkbox"
                  checked={enhanceVehicleDetails}
                  onChange={(event) => setEnhanceVehicleDetails(event.target.checked)}
                  className="mt-1 size-4"
                />
                <span>
                  <span className="font-medium">Enhanced vehicle detail analysis</span>
                  <span className="mt-1 block text-xs text-muted-foreground">
                    Recover low-confidence car/smoke/plate detections in wide CCTV frames using a higher-resolution vehicle-only pass, then run an enlarged vehicle-region pass for small smoke and plate details.
                  </span>
                </span>
              </label>

              {enhanceVehicleDetails && (
                <div className="mt-4 grid gap-3 sm:grid-cols-3">
                  <label className="space-y-1 text-xs text-muted-foreground">
                    <span>Car recovery threshold</span>
                    <input
                      type="number" min={0.01} max={1} step={0.01} value={carRecoveryConfidence}
                      onChange={(event) => setCarRecoveryConfidence(Number(event.target.value))}
                      className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm text-foreground"
                    />
                  </label>
                  <label className="space-y-1 text-xs text-muted-foreground">
                    <span>Smoke recovery threshold</span>
                    <input
                      type="number" min={0.01} max={1} step={0.01} value={smokeDetailConfidence}
                      onChange={(event) => setSmokeDetailConfidence(Number(event.target.value))}
                      className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm text-foreground"
                    />
                  </label>
                  <label className="space-y-1 text-xs text-muted-foreground">
                    <span>Plate recovery threshold</span>
                    <input
                      type="number" min={0.01} max={1} step={0.01} value={plateDetailConfidence}
                      onChange={(event) => setPlateDetailConfidence(Number(event.target.value))}
                      className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm text-foreground"
                    />
                  </label>
                </div>
              )}
            </div>

            {mode === "video" && (
              <div className="rounded-lg border border-border bg-muted/20 p-4">
                <div>
                  <span className="font-medium text-sm">Temporal smoke evidence</span>
                  <p className="mt-1 text-xs text-muted-foreground">
                    Smoke may disappear between YOLO frames even when the real plume is continuous. These settings group intermittent smoke hits around the same tracked car.
                  </p>
                </div>
                <div className="mt-4 grid gap-3 sm:grid-cols-3">
                  <label className="space-y-1 text-xs text-muted-foreground">
                    <span>Evidence window (seconds)</span>
                    <input
                      type="number" min={0.5} max={10} step={0.5} value={smokeWindowSeconds}
                      onChange={(event) => setSmokeWindowSeconds(Number(event.target.value))}
                      className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm text-foreground"
                    />
                  </label>
                  <label className="space-y-1 text-xs text-muted-foreground">
                    <span>Hits for candidate</span>
                    <input
                      type="number" min={2} max={10} step={1} value={smokeCandidateHits}
                      onChange={(event) => setSmokeCandidateHits(Number(event.target.value))}
                      className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm text-foreground"
                    />
                  </label>
                  <label className="space-y-1 text-xs text-muted-foreground">
                    <span>Hits for strong candidate</span>
                    <input
                      type="number" min={3} max={20} step={1} value={smokeStrongHits}
                      onChange={(event) => setSmokeStrongHits(Number(event.target.value))}
                      className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm text-foreground"
                    />
                  </label>
                </div>
                <p className="mt-3 text-[11px] text-muted-foreground">
                  Default policy: 1 hit = observation only, 2 hits in 3 seconds = candidate, 3+ hits = strong candidate. No smoke is required on every sampled frame.
                </p>
              </div>
            )}

            <label className="flex cursor-pointer flex-col items-center justify-center rounded-xl border border-dashed border-border bg-muted/20 px-6 py-10 text-center transition hover:bg-muted/35">
              <Upload className="size-8 text-primary" />
              <span className="mt-3 font-medium">{file ? file.name : `Choose ${mode === "image" ? "an image" : "a video"}`}</span>
              <span className="mt-1 text-xs text-muted-foreground">
                {mode === "image" ? "JPG, PNG, BMP or WEBP" : "MP4, AVI, MOV, MKV, WEBM or M4V"}
              </span>
              <input
                type="file" className="hidden" accept={mode === "image" ? "image/*" : "video/*"}
                onChange={(event) => chooseFile(event.target.files?.[0] || null)}
              />
            </label>

            {error && <div className="rounded-lg border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-300">{error}</div>}

            <button
              type="submit" disabled={!file || loading}
              className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground disabled:opacity-50"
            >
              {loading ? <Loader2 className="size-4 animate-spin" /> : <BrainCircuit className="size-4" />}
              {loading ? "Running model and rules..." : "Run AI test"}
            </button>
          </form>

          {preview && mode === "image" && (
            <div className="mt-5 overflow-hidden rounded-xl border border-border bg-black">
              <div className="relative inline-block w-full">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={preview} alt="AI test" className="block h-auto w-full" />
                {imageResult?.detections.map((detection, index) => {
                  const left = (detection.bbox.x1 / imageResult.image_width) * 100
                  const top = (detection.bbox.y1 / imageResult.image_height) * 100
                  const width = (detection.bbox.width / imageResult.image_width) * 100
                  const height = (detection.bbox.height / imageResult.image_height) * 100
                  return (
                    <div
                      key={`${detection.class_name}-${index}`}
                      className="pointer-events-none absolute border-2 border-primary"
                      style={{ left: `${left}%`, top: `${top}%`, width: `${width}%`, height: `${height}%` }}
                    >
                      <span className="absolute -top-6 left-0 whitespace-nowrap rounded bg-primary px-1.5 py-0.5 text-[11px] font-semibold text-primary-foreground">
                        {detection.class_name} {confidencePercent(detection.confidence)}{detection.source === "vehicle_detail" ? " · detail" : ""}
                      </span>
                    </div>
                  )
                })}
              </div>
            </div>
          )}

          {preview && mode === "video" && (
            <div className="mt-5">
              <div className="relative overflow-hidden rounded-xl border border-border bg-black">
                <video
                  ref={videoRef}
                  src={preview}
                  controls
                  className="block h-auto w-full"
                  onTimeUpdate={(event) => setCurrentVideoTime(event.currentTarget.currentTime)}
                  onSeeked={(event) => setCurrentVideoTime(event.currentTarget.currentTime)}
                  onLoadedMetadata={(event) => {
                    event.currentTarget.playbackRate = playbackRate
                    setCurrentVideoTime(0)
                  }}
                />
                {videoResult && activeVideoFrame?.detections.map((detection, index) => {
                  const left = (detection.bbox.x1 / activeVideoFrame.image_width) * 100
                  const top = (detection.bbox.y1 / activeVideoFrame.image_height) * 100
                  const width = (detection.bbox.width / activeVideoFrame.image_width) * 100
                  const height = (detection.bbox.height / activeVideoFrame.image_height) * 100
                  const predicted = Boolean(detection.is_predicted || detection.tracking_state === "predicted")
                  return (
                    <div
                      key={`${activeVideoFrame.frame_index}-${detection.track_id ?? detection.class_name}-${index}`}
                      className={`pointer-events-none absolute border-2 ${predicted ? "border-dashed border-amber-400" : "border-primary"}`}
                      style={{ left: `${left}%`, top: `${top}%`, width: `${width}%`, height: `${height}%` }}
                    >
                      <span className={`absolute -top-6 left-0 whitespace-nowrap rounded px-1.5 py-0.5 text-[11px] font-semibold ${predicted ? "bg-amber-400 text-black" : "bg-primary text-primary-foreground"}`}>
                        {detection.dumping_role === "unclassified_waste_candidate" ? "unclassified waste/debris" : detection.class_name} {confidencePercent(detection.confidence)}
                        {detection.track_id ? ` · ${detection.track_id}` : ""}
                        {detection.waste_state ? ` · ${label(detection.waste_state).toUpperCase()}` : ""}
                        {detection.associated_actor_track_id ? ` ← ${detection.associated_actor_track_id}` : ""}
                        {(detection.associated_waste_track_ids?.length ?? 0) > 0 ? ` · waste ${detection.associated_waste_track_ids!.join(",")}` : ""}
                        {predicted ? " · TRACKED" : detection.source !== "primary" ? ` · ${detection.source}` : ""}
                      </span>
                    </div>
                  )
                })}
              </div>
              {videoResult && (
                <div className="mt-3 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border bg-muted/20 p-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => seekToSample(-1)}
                      disabled={activeVideoFrameIndex <= 0}
                      className="inline-flex h-8 items-center gap-1 rounded-md border border-border px-2.5 text-xs disabled:opacity-40"
                    >
                      <ChevronLeft className="size-3.5" /> Previous AI frame
                    </button>
                    <button
                      type="button"
                      onClick={() => seekToSample(1)}
                      disabled={activeVideoFrameIndex < 0 || activeVideoFrameIndex >= videoResult.sampled_detections.length - 1}
                      className="inline-flex h-8 items-center gap-1 rounded-md border border-border px-2.5 text-xs disabled:opacity-40"
                    >
                      Next AI frame <ChevronRight className="size-3.5" />
                    </button>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Gauge className="size-3.5" />
                    <span>Review speed</span>
                    {[0.25, 0.5, 1].map((rate) => (
                      <button
                        key={rate}
                        type="button"
                        onClick={() => applyPlaybackRate(rate)}
                        className={`rounded-md border px-2 py-1 ${playbackRate === rate ? "border-primary bg-primary/10 text-primary" : "border-border"}`}
                      >
                        {rate}x
                      </button>
                    ))}
                  </div>
                </div>
              )}
              {videoResult && (
                <div className="mt-2 flex flex-wrap items-center gap-4 rounded-lg border border-border bg-muted/10 px-3 py-2 text-[11px] text-muted-foreground">
                  <span className="inline-flex items-center gap-2"><span className="inline-block h-3 w-5 border-2 border-primary" /> Direct YOLO detection</span>
                  <span className="inline-flex items-center gap-2"><span className="inline-block h-3 w-5 border-2 border-dashed border-amber-400" /> Tracker-held/predicted box</span>
                  <span>Predicted boxes preserve visual continuity but do not count as fresh rule evidence.</span>
                </div>
              )}
              {videoResult && activeVideoFrame && (
                <div className="mt-2 flex flex-wrap items-center justify-between gap-2 text-xs text-muted-foreground">
                  <span>AI overlay: source frame {activeVideoFrame.frame_index} · {activeVideoFrame.time_seconds.toFixed(2)}s · sample {activeVideoFrameIndex + 1}/{videoResult.sampled_detections.length}</span>
                  <span>{activeVideoFrame.detections.length} detection(s) · analysed every {videoResult.frame_stride} source frame(s)</span>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="space-y-5">
          <section className="rounded-xl border border-border bg-card p-5 shadow-sm">
            <h2 className="font-semibold">Model output</h2>
            {!imageResult && !videoResult ? (
              <p className="mt-3 text-sm text-muted-foreground">Run a test to see detections.</p>
            ) : imageResult ? (
              <div className="mt-4 space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <Metric label="Detections" value={String(imageResult.detections_count)} />
                  <Metric label="Associations" value={String(imageResult.associations.length)} />
                </div>
                {detectionsByClass.map(([name, items]) => (
                  <div key={name} className="flex items-center justify-between rounded-lg bg-muted/35 px-3 py-2 text-sm">
                    <span>{name}</span>
                    <span className="text-muted-foreground">
                      {items.length} · best {confidencePercent(Math.max(...items.map((item) => item.confidence)))}
                    </span>
                  </div>
                ))}
                {imageResult.detections.some((item) => item.source === "vehicle_detail") && (
                  <div className="rounded-lg border border-primary/20 bg-primary/5 px-3 py-2 text-xs text-muted-foreground">
                    Enhanced vehicle crop analysis recovered/strengthened one or more plate/smoke detections.
                  </div>
                )}
              </div>
            ) : (
              <div className="mt-4 space-y-3">
                <div className={`rounded-xl border p-4 ${
                  dumpingCandidate
                    ? "border-amber-500/40 bg-amber-500/10"
                    : dumpingObservation
                      ? "border-blue-500/30 bg-blue-500/10"
                      : "border-border bg-muted/20"
                }`}>
                  <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Illegal-dumping verdict</p>
                  <p className={`mt-1 text-lg font-semibold ${dumpingCandidate ? "text-amber-300" : dumpingObservation ? "text-blue-300" : "text-foreground"}`}>
                    {dumpingCandidate
                      ? "POSSIBLE ILLEGAL DUMPING DETECTED"
                      : dumpingObservation
                        ? "POTENTIAL DUMPING UNDER REVIEW"
                        : "NO ILLEGAL-DUMPING EVENT CONFIRMED"}
                  </p>
                  <p className="mt-2 text-xs text-muted-foreground">
                    {dumpingCandidate
                      ? dumpingCandidate.reasons[0] ?? "Waste/debris was deposited and remained after the associated actor/vehicle moved away."
                      : dumpingObservation
                        ? dumpingObservation.reasons[0] ?? "An actor/vehicle and waste/debris sequence is being evaluated."
                        : hasActorEvidence && !hasPrimaryWasteEvidence && !hasAuxiliaryWasteEvidence
                          ? "Person/car activity was detected, but the current detector produced no usable trash, bag or auxiliary waste/debris track to complete the dumping lifecycle."
                          : "The required deposit + departure + persistence sequence was not completed."}
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <Metric label="Duration" value={`${videoResult!.duration_seconds}s`} />
                  <Metric label="Tracked objects" value={String(videoResult!.tracks.length)} />
                  <Metric label="Sampled frames" value={String(videoResult!.sampled_frames)} />
                  <Metric label="Occurrences" value={String(videoResult!.occurrences.length)} />
                  <Metric label="Video coverage" value={`${(videoResult!.analysis_coverage_percent ?? 100).toFixed(1)}%`} />
                  <Metric label="Effective stride" value={String(videoResult!.effective_frame_stride ?? videoResult!.frame_stride)} />
                  <Metric label="Tracker-held boxes" value={String(videoResult!.predicted_boxes_count ?? 0)} />
                </div>
                {(videoResult!.effective_frame_stride ?? videoResult!.frame_stride) !== (videoResult!.requested_frame_stride ?? videoResult!.frame_stride) && (
                  <div className="rounded-lg border border-amber-500/20 bg-amber-500/5 px-3 py-2 text-xs text-muted-foreground">
                    This clip was long enough that the backend increased the stride uniformly to cover the whole video instead of stopping part-way through it.
                  </div>
                )}
                <div className="rounded-lg border border-border bg-muted/20 px-3 py-2 text-xs text-muted-foreground">
                  Illegal-dumping decisions use person/car + waste movement + stationary deposit + departure + persistence. License plates are intentionally excluded from the dumping decision and can be added later as separate evidence.
                </div>
                <div className="rounded-lg border border-violet-500/20 bg-violet-500/5 px-3 py-2 text-xs text-muted-foreground">
                  Dumping can involve furniture, bicycles, appliances or mixed debris that are not current YOLO classes. A sparse/small skip-like detection may therefore be shown as <span className="font-medium text-foreground">unclassified waste/debris</span> for dumping correlation only. The original model class remains unchanged.
                </div>
                {videoResult!.class_summary.map((item) => (
                  <div key={item.class_name} className="flex items-center justify-between rounded-lg bg-muted/35 px-3 py-2 text-sm">
                    <span>{item.class_name}</span>
                    <span className="text-muted-foreground">{item.detections} direct model hit{item.detections === 1 ? "" : "s"} · best {confidencePercent(item.max_confidence)}</span>
                  </div>
                ))}
                {activeVideoFrame && (
                  <div className="rounded-lg border border-border bg-muted/20 p-3">
                    <p className="text-xs font-medium">Current sampled-frame detections</p>
                    <p className="mt-1 text-[11px] text-muted-foreground">Nearest analysed frame to the current video time.</p>
                    <div className="mt-2 space-y-1">
                      {activeVideoFrame.detections.length === 0 ? (
                        <p className="text-xs text-muted-foreground">No detections on this sampled frame.</p>
                      ) : activeVideoFrame.detections.map((item, index) => (
                        <div key={`${item.track_id ?? item.class_name}-${index}`} className="flex justify-between gap-3 text-xs">
                          <span>
                            {item.dumping_role === "unclassified_waste_candidate" ? "unclassified waste/debris" : item.class_name}{item.track_id ? ` · ${item.track_id}` : ""}
                            {item.dumping_role === "unclassified_waste_candidate" ? " · AUXILIARY DUMPING ROLE" : ""}
                            {item.waste_state ? ` · ${label(item.waste_state).toUpperCase()}` : ""}
                            {item.associated_actor_track_id ? ` ← ${item.associated_actor_track_id}` : ""}
                            {item.is_predicted ? " · TRACKED" : ""}
                          </span>
                          <span className="text-muted-foreground">{confidencePercent(item.confidence)}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </section>

          {(imageResult?.associations.length ?? 0) > 0 && (
            <section className="rounded-xl border border-border bg-card p-5 shadow-sm">
              <div className="flex items-center gap-2"><Link2 className="size-4 text-primary" /><h2 className="font-semibold">Object associations</h2></div>
              <div className="mt-3 space-y-2">
                {imageResult!.associations.map((item, index) => (
                  <div key={`${item.association_type}-${index}`} className="rounded-lg bg-muted/30 px-3 py-2 text-xs">
                    <div className="flex justify-between gap-3"><span className="font-medium">{label(item.association_type)}</span><span className="text-muted-foreground">{confidencePercent(item.confidence)}</span></div>
                    <p className="mt-1 text-muted-foreground">{item.left_class} ↔ {item.right_class} · {label(item.relation)}</p>
                  </div>
                ))}
              </div>
            </section>
          )}

          {(videoResult?.association_summary.length ?? 0) > 0 && (
            <section className="rounded-xl border border-border bg-card p-5 shadow-sm">
              <div className="flex items-center gap-2"><Link2 className="size-4 text-primary" /><h2 className="font-semibold">Association summary</h2></div>
              <div className="mt-3 space-y-2">
                {videoResult!.association_summary.map((item) => (
                  <div key={item.association_type} className="flex justify-between rounded-lg bg-muted/30 px-3 py-2 text-sm">
                    <span>{label(item.association_type)}</span><span className="text-muted-foreground">{item.hits} hits</span>
                  </div>
                ))}
              </div>
            </section>
          )}

          {cleanliness && <CleanlinessCard value={cleanliness} />}
          {videoResult?.cleaner_performance && <CleanerPerformanceCard value={videoResult.cleaner_performance} />}
        </div>
      </section>

      <section className="grid gap-5 xl:grid-cols-2">
        <section className="rounded-xl border border-border bg-card p-5 shadow-sm">
          <div className="flex items-center gap-2"><ScanLine className="size-4 text-primary" /><h2 className="font-semibold">Occurrence intelligence</h2></div>
          <p className="mt-1 text-xs text-muted-foreground">Grouped events/states produced from raw detections, associations and video time.</p>
          <div className="mt-4 space-y-3">
            {occurrences.length === 0 ? <p className="text-sm text-muted-foreground">No occurrence conditions were met.</p> : occurrences.map((item) => <OccurrenceCard key={item.occurrence_id} occurrence={item} />)}
          </div>
        </section>

        <section className="rounded-xl border border-border bg-card p-5 shadow-sm">
          <h2 className="font-semibold">Rule engine</h2>
          <p className="mt-1 text-xs text-muted-foreground">Candidate rules require operational validation before automatic incident creation.</p>
          <div className="mt-4 space-y-3">
            {rules.length === 0 ? <p className="text-sm text-muted-foreground">No rule conditions were met.</p> : rules.map((rule) => <RuleCard key={rule.rule} rule={rule} />)}
          </div>
        </section>
      </section>
    </div>
  )
}

function InfoRow({ name, value }: { name: string; value: string }) {
  return (
    <div className="rounded-md bg-muted/30 px-2.5 py-2">
      <span className="text-muted-foreground">{name}: </span><span className="font-medium">{value}</span>
    </div>
  )
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-muted/35 p-3">
      <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className="mt-1 text-lg font-semibold">{value}</p>
    </div>
  )
}
